'use client';

import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRightIcon } from '@heroicons/react/24/outline';

interface TravelProduct {
  id: string;
  title: string;
  description: string;
  price: {
    adult: number;
    child: number;
    infant: number;
    fuelSurcharge: number;
  };
  images: {
    src: string;
    alt: string;
    localPath: string;
  }[];
  region: string;
  isTimeDeal: boolean;
  createdAt: string;
}

export default function TravelPage() {
  const [regionalProducts, setRegionalProducts] = useState<TravelProduct[]>([]);
  const [timeDealProducts, setTimeDealProducts] = useState<TravelProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const productsRef = collection(db, 'travel_products');

        // 지역별 여행 상품 조회
        const regionalQuery = query(productsRef, where('isTimeDeal', '==', false));
        const regionalSnapshot = await getDocs(regionalQuery);
        const regionalData = regionalSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })) as TravelProduct[];
        setRegionalProducts(regionalData);

        // 타임딜 상품 조회
        const timeDealQuery = query(productsRef, where('isTimeDeal', '==', true));
        const timeDealSnapshot = await getDocs(timeDealQuery);
        const timeDealData = timeDealSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })) as TravelProduct[];
        setTimeDealProducts(timeDealData);
      } catch (error) {
        console.error('Error fetching travel products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="mx-auto mb-4 size-12 animate-spin rounded-full border-y-2 border-blue-500"></div>
          <p className="text-gray-600">로딩 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 지역별 여행 섹션 */}
      <section className="mb-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">지역별 여행</h2>
          <Link
            href="/travel/free_travel"
            className="flex items-center gap-1 text-blue-600 hover:text-blue-800"
          >
            더보기
            <ArrowRightIcon className="size-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {regionalProducts.map(product => (
            <Link key={product.id} href={`/travel/free_travel/${product.id}`} className="group">
              <div className="overflow-hidden rounded-lg bg-white shadow-lg">
                <div className="relative h-48">
                  <Image
                    src={product.images[0]?.localPath || '/images/placeholder.jpg'}
                    alt={product.images[0]?.alt || product.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="mb-2 line-clamp-2 text-lg font-semibold">{product.title}</h3>
                  <p className="mb-3 line-clamp-2 text-sm text-gray-600">{product.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-600">
                      {product.price.adult.toLocaleString()}원
                    </span>
                    <span className="text-sm text-gray-500">{product.region}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 타임딜 섹션 */}
      <section>
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">타임딜</h2>
          <Link
            href="/travel/free_travel?type=timeDeal"
            className="flex items-center gap-1 text-blue-600 hover:text-blue-800"
          >
            더보기
            <ArrowRightIcon className="size-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {timeDealProducts.map(product => (
            <Link key={product.id} href={`/travel/free_travel/${product.id}`} className="group">
              <div className="overflow-hidden rounded-lg bg-white shadow-lg">
                <div className="relative h-48">
                  <Image
                    src={product.images[0]?.localPath || '/images/placeholder.jpg'}
                    alt={product.images[0]?.alt || product.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute right-2 top-2 rounded bg-red-500 px-2 py-1 text-sm text-white">
                    타임딜
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="mb-2 line-clamp-2 text-lg font-semibold">{product.title}</h3>
                  <p className="mb-3 line-clamp-2 text-sm text-gray-600">{product.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-600">
                      {product.price.adult.toLocaleString()}원
                    </span>
                    <span className="text-sm text-gray-500">{product.region}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
